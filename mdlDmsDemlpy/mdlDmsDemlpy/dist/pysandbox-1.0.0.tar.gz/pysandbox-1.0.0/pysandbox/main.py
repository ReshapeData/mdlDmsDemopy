from data import myAdd


if __name__ =='__main__':
    myvalue = myAdd(3,4)
    print(myvalue)