if __name__ == '__main__':
    mydata = ['a','b','c']
    mydata2 = tuple(mydata)
    for i in range(len(mydata)):
        print(mydata[i])