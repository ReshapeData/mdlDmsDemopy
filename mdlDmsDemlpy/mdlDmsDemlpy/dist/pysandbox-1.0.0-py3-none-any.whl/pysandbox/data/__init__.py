#将下级的变量导入到上一级
#这是不错的处理
from .dataset import myAdd