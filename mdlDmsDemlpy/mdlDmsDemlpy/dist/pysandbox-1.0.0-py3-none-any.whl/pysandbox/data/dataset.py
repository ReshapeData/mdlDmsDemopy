def myAdd(x,y):
    return(x+y)




if __name__ == '__main__':
    myValue = myAdd(1,2)
    print(myValue)